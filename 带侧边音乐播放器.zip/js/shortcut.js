//id,iconName,iconUrl,url,width,height
var shortcut = [
[0,"我的电脑","images/icos/01.png","http://cloud.2345.ltd/?",1000,550],
[1,"我的相册","images/icos/02.png","http://660000.xyz/?jsEffects/2014091502/",1000,550],
[2,"我的音乐","images/icos/03.png","http://www.odj.cc/?jsEffects/2014101006/",1000,550],
[3,"视频解析","images/icos/vip.gif","http://vip.2345.ltd/?jsEffects/2015011410/",1000,550],
[4,"古典诗词","images/icos/poem.gif","http://www.free163.com/?jsEffects/2015011409/",1000,550],
[5,"我的邮局","images/icos/mail.gif","http://mail.pu.cx/?jsEffects/2015011405/",1000,550],
[6,"阿里云盘","images/icos/aliyun.gif","http://alist.2345.ltd/?jsEffects/2015011203/",1000,550],
[7,"云分享","images/icos/share.gif","http://kylehao.ysepan.com/?jsEffects/2015010304/",1000,550],
[8,"云下载","images/icos/09.png","http://pan.2345.ltd/?jsEffects/2015010304/",1000,550],
[9,"我的博客","images/icos/blog.gif","http://blog.444.info/?jsEffects/2015010802/",1000,550],
[10,"我的米表","images/icos/zyxyy.gif","http://www.kkkk.info/?jsEffects/2015010901/",1000,550],
[11,"德云社","images/icos/dys.gif","http://44444.ltd/?jsEffects/2015010901/",1000,550],
];